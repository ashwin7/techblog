---
title: Object Oriented Twitter
date: 2015-08-27 
path: "/blog/object-oriented-twitter.html"
tags: ruby, tutorials, OOP
---

Slide deck from my talk at Launch Academy.

<iframe src="https://www.slideshare.net/slideshow/embed_code/key/NKw2NSUfBlPqMx" width="427" height="356" frameborder="0" marginwidth="0" marginheight="0" scrolling="no" style="border:1px solid #CCC; border-width:1px; margin-bottom:5px; max-width: 100%;" allowfullscreen> </iframe> <div style="margin-bottom:5px"> <strong> <a href="https://www.slideshare.net/secret/NKw2NSUfBlPqMx" title="Object Oriented Twitter Slidedeck" target="_blank">Object Oriented Twitter Slidedeck</a> </strong> from <strong><a href="http://www.slideshare.net/SpencerDixon2" target="_blank">Spencer Dixon</a></strong> </div>
